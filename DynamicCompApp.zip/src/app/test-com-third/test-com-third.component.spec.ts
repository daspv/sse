import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestComThirdComponent } from './test-com-third.component';

describe('TestComThirdComponent', () => {
  let component: TestComThirdComponent;
  let fixture: ComponentFixture<TestComThirdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestComThirdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComThirdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
