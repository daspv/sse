import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-test-com-third',
  templateUrl: './test-com-third.component.html',
  styleUrls: ['./test-com-third.component.css']
})
export class TestComThirdComponent implements OnInit {

  @Input() count : number;
  constructor() { }

  ngOnInit(): void {
  }

}
