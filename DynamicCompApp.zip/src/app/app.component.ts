import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DynamicComp';
  conditionDispOne : boolean;
  conditionDispTwo : boolean;
  conditionDispThree : boolean;
  conditionDispFour : boolean;
  blockNumber : any

  constructor(){
    this.conditionDispOne = false;
    this.conditionDispTwo = false;
    this.conditionDispThree = false;
    this.conditionDispFour = false;
  }

  toggleDiv(blckNbr : any){
    console.log(blckNbr);
    this.blockNumber = blckNbr;
    console.log(typeof blckNbr);
    //alert(this.blockNumber);
    switch (blckNbr) {
      case '1':
        console.log("1");
        this.conditionDispOne = !this.conditionDispOne
        break;
      case '2':
        console.log("2");
        this.conditionDispTwo = !this.conditionDispTwo
        break;
      case '3':
        console.log("3");
        this.conditionDispThree = !this.conditionDispThree
        break;
      case '4':
        console.log("4");
        this.conditionDispFour = !this.conditionDispFour
        break;
      default:
        break;
    }
  }
}
