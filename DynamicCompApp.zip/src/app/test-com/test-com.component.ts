import { Component, OnInit , Input} from '@angular/core';

@Component({
  selector: 'app-test-com',
  templateUrl: './test-com.component.html',
  styleUrls: ['./test-com.component.css']
})
export class TestComComponent implements OnInit {

  @Input() count : number;
  constructor() { }

  ngOnInit(): void {
  }

}
