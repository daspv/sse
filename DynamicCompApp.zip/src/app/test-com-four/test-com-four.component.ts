import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-test-com-four',
  templateUrl: './test-com-four.component.html',
  styleUrls: ['./test-com-four.component.css']
})
export class TestComFourComponent implements OnInit {

  @Input() count : number;
  constructor() { }

  ngOnInit(): void {
  }

}
