import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BlockoneComponent } from './blockone/blockone.component';
import { TestComComponent } from './test-com/test-com.component';
import { TestComSecondComponent } from './test-com-second/test-com-second.component';
import { TestComThirdComponent } from './test-com-third/test-com-third.component';
import { TestComFourComponent } from './test-com-four/test-com-four.component';

@NgModule({
  declarations: [
    AppComponent,
    BlockoneComponent,
    TestComComponent,
    TestComSecondComponent,
    TestComThirdComponent,
    TestComFourComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
