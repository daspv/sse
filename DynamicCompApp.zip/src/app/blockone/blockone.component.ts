import { Component, OnInit , EventEmitter , Output, Input } from '@angular/core';

@Component({
  selector: 'app-blockone',
  templateUrl: './blockone.component.html',
  styleUrls: ['./blockone.component.css']
})
export class BlockoneComponent implements OnInit {
 
  @Output('blockNumber') blkNbr = new EventEmitter<string>();
  @Input() blockCount: number;

  sendBlockNumber(blck : any){
    this.blkNbr.emit(blck);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
