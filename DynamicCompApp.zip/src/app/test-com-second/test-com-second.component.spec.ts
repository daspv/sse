import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestComSecondComponent } from './test-com-second.component';

describe('TestComSecondComponent', () => {
  let component: TestComSecondComponent;
  let fixture: ComponentFixture<TestComSecondComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestComSecondComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestComSecondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
