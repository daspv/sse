import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-test-com-second',
  templateUrl: './test-com-second.component.html',
  styleUrls: ['./test-com-second.component.css']
})
export class TestComSecondComponent implements OnInit {

  @Input() count : number;
  constructor() { }

  ngOnInit(): void {
  }

}
